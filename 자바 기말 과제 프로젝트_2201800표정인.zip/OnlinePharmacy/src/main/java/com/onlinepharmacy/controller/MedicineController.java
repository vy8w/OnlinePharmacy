package com.onlinepharmacy.controller;

import com.onlinepharmacy.model.Medicine;
import com.onlinepharmacy.service.MedicineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/medicines")
public class MedicineController {

    @Autowired
    private MedicineService medicineService;

    @GetMapping
    public String listMedicines(Model model) {
        List<Medicine> medicines = medicineService.findAll();
        model.addAttribute("medicines", medicines);
        return "medicine";
    }

    @GetMapping("/search")
    public String searchMedicines(@RequestParam("name") String name, Model model) {
        List<Medicine> medicines = medicineService.findByName(name);
        model.addAttribute("medicines", medicines);
        return "medicine";
    }

    @PostMapping("/save")
    public String saveMedicine(@ModelAttribute Medicine medicine) {
        medicineService.save(medicine);
        return "redirect:/medicines";
    }

    @GetMapping("/edit/{id}")
    public String editMedicine(@PathVariable Long id, Model model) {
        Medicine medicine = medicineService.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid medicine Id:" + id));
        model.addAttribute("medicine", medicine);
        return "edit_medicine";
    }

    @GetMapping("/delete/{id}")
    public String deleteMedicine(@PathVariable Long id) {
        medicineService.deleteById(id);
        return "redirect:/medicines";
    }
}