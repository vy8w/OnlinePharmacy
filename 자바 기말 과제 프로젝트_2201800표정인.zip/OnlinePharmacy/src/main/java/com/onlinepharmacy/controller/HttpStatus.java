package com.onlinepharmacy.controller;

public class HttpStatus {

	public static final org.springframework.http.HttpStatus NOT_FOUND = null;

}
