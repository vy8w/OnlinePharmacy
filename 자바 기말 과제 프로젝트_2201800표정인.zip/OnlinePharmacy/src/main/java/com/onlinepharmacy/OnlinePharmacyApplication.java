package com.onlinepharmacy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePharmacyApplication {
    public static void main(String[] args) {
        SpringApplication.run(OnlinePharmacyApplication.class, args);
    }
}
