package junit.framework;

public class TestCase {

}
