package junit.framework;

public class TestSuite {

}
